﻿using System;
using System.Collections.Generic;

namespace CyberSecurityBot.Core
{
    // Delegate definition for response selection
    public delegate string ResponseSelector(List<string> responses);

    public class SentimentAnalyzer
    {
        private readonly Dictionary<string, string> _sentimentKeywords = new Dictionary<string, string>
        {
            { "worried", "concerned" },
            { "scared", "concerned" },
            { "afraid", "concerned" },
            { "fear", "concerned" },
            { "anxious", "concerned" },
            { "concerned", "concerned" },
            { "confused", "confused" },
            { "confusing", "confused" },
            { "don't understand", "confused" },
            { "help", "confused" },
            { "happy", "positive" },
            { "great", "positive" },
            { "thanks", "positive" },
            { "thank you", "positive" },
            { "good", "positive" },
            { "excellent", "positive" }
        };

        public string DetectSentiment(string userInput)
        {
            string lowerInput = userInput.ToLower();

            foreach (var keyword in _sentimentKeywords)
            {
                if (lowerInput.Contains(keyword.Key))
                {
                    return keyword.Value;
                }
            }

            return "neutral";
        }

        public string GetEmpatheticResponse(string sentiment)
        {
            switch (sentiment)
            {
                case "concerned":
                    return "I understand your concern. Let me help you with that.";
                case "confused":
                    return "No worries! Let me explain this more clearly.";
                case "positive":
                    return "Great! I'm glad I could help!";
                default:
                    return "Thanks for sharing that with me.";
            }
        }
    }
}