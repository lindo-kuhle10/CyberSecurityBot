﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CyberSecurityBot.Core
{
    public class ResponseManager
    {
        private Dictionary<string, List<string>> _responses;
        private Random _random;
        private ResponseSelector _selector;

        public ResponseManager()
        {
            _random = new Random();
            _selector = SelectRandomResponse; // Using delegate!
            InitializeResponses();
        }

        private void InitializeResponses()
        {
            _responses = new Dictionary<string, List<string>>
            {
                { "password", new List<string>
                    {
                        "Use strong, unique passwords for each account. Avoid using personal details in your passwords.",
                        "Create passwords with at least 12 characters, mixing uppercase, lowercase, numbers, and symbols.",
                        "Consider using a password manager to generate and store complex passwords securely."
                    }
                },
                { "phishing", new List<string>
                    {
                        "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organizations.",
                        "Always verify the sender's email address. Hover over links before clicking to see the actual URL.",
                        "Never provide sensitive information via email. Legitimate companies won't ask for passwords or credit card numbers via email."
                    }
                },
                { "scam", new List<string>
                    {
                        "Be skeptical of unsolicited calls or messages asking for money or personal information.",
                        "If an offer seems too good to be true, it probably is. Always verify before acting.",
                        "Never share your OTP, PIN, or banking details with anyone, even if they claim to be from your bank."
                    }
                },
                { "privacy", new List<string>
                    {
                        "Review your social media privacy settings regularly. Limit who can see your personal information.",
                        "Be careful about what you share online. Once posted, it's difficult to completely remove.",
                        "Use privacy-focused search engines and browsers to protect your online activity."
                    }
                },
                { "malware", new List<string>
                    {
                        "Keep your antivirus software updated and run regular scans.",
                        "Only download software from official sources. Avoid pirated software.",
                        "Be careful with email attachments, even from known contacts."
                    }
                },
                { "2fa", new List<string>
                    {
                        "Enable two-factor authentication on all important accounts for an extra layer of security.",
                        "Use authenticator apps like Google Authenticator instead of SMS when possible.",
                        "Keep backup codes in a safe place in case you lose access to your 2FA device."
                    }
                }
            };
        }

        public string GetRandomResponse(string keyword)
        {
            string lowerKeyword = keyword.ToLower();

            foreach (var key in _responses.Keys)
            {
                if (lowerKeyword.Contains(key))
                {
                    var responses = _responses[key];
                    return _selector(responses); // Using delegate to select response
                }
            }

            return null;
        }

        private string SelectRandomResponse(List<string> responses)
        {
            return responses[_random.Next(responses.Count)];
        }

        public bool ContainsKeyword(string userInput)
        {
            string lowerInput = userInput.ToLower();
            return _responses.Keys.Any(keyword => lowerInput.Contains(keyword));
        }

        public string GetFollowUpResponse(string topic)
        {
            if (string.IsNullOrEmpty(topic))
                return "Could you tell me more about what you'd like to know?";

            return GetRandomResponse(topic);
        }
    }
}