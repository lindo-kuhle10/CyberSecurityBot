﻿using System;
using System.Collections.Generic;

namespace CyberSecurityBot.Core
{
    public class MemoryManager
    {
        private Dictionary<string, string> _userMemory = new Dictionary<string, string>();

        public void Store(string key, string value)
        {
            if (_userMemory.ContainsKey(key)) 
            {
                _userMemory[key] = value;
            }
            else
            {
                _userMemory.Add(key, value);
            }
        }

        public string Recall(string key)
        {
            if (_userMemory.ContainsKey(key))
            {
                return _userMemory[key];
            }
            return null;
        }

        public bool HasMemory(string key)
        {
            return _userMemory.ContainsKey(key);
        }

        public void Clear()
        {
            _userMemory.Clear();
        }
    }
}