﻿using System;

namespace CyberSecurityBot.Core
{
    public class ChatBot
    {
        private ResponseManager _responseManager;
        private SentimentAnalyzer _sentimentAnalyzer;
        private MemoryManager _memoryManager;
        private string _lastTopic;


        public ChatBot(ResponseManager responseManager, SentimentAnalyzer sentimentAnalyzer, MemoryManager memoryManager)
        {
            _responseManager = responseManager;
            _sentimentAnalyzer = sentimentAnalyzer;
            _memoryManager = memoryManager;
            _lastTopic = "";
        }

        public string ProcessInput(string userInput, string sentiment, out string lastTopic)
        {
            string lowerInput = userInput.ToLower();
            lastTopic = _lastTopic;

            // Check for name (first interaction)
            if (!_memoryManager.HasMemory("UserName") &&
                !_responseManager.ContainsKeyword(userInput))
            {
                _memoryManager.Store("UserName", userInput);
                return $"Nice to meet you, {userInput}! What cybersecurity topic would you like to learn about? Try asking about: passwords, phishing, scams, privacy, malware, or 2FA.";
            }

            // Check for follow-up requests
            if (lowerInput.Contains("tell me more") || lowerInput.Contains("explain more") ||
                lowerInput.Contains("another tip") || lowerInput.Contains("more"))
            {
                if (!string.IsNullOrEmpty(_lastTopic))
                {
                    return _responseManager.GetFollowUpResponse(_lastTopic);
                }
                return "Could you specify which topic you'd like to know more about?";
            }

            // Check for keywords
            if (_responseManager.ContainsKeyword(userInput))
            {
                // Store favorite topic
                if (!_memoryManager.HasMemory("FavoriteTopic"))
                {
                    if (lowerInput.Contains("password")) _memoryManager.Store("FavoriteTopic", "password");
                    else if (lowerInput.Contains("phishing")) _memoryManager.Store("FavoriteTopic", "phishing");
                    else if (lowerInput.Contains("scam")) _memoryManager.Store("FavoriteTopic", "scam");
                    else if (lowerInput.Contains("privacy")) _memoryManager.Store("FavoriteTopic", "privacy");
                }

                _lastTopic = GetKeywordFromInput(lowerInput);
                lastTopic = _lastTopic;
                string response = _responseManager.GetRandomResponse(userInput);

                // Personalize response if we remember their interest
                if (_memoryManager.HasMemory("FavoriteTopic") && _memoryManager.Recall("FavoriteTopic") == _lastTopic)
                {
                    string userName = _memoryManager.Recall("UserName");
                    return $"As someone interested in {_lastTopic}, {userName}, here's a tip: {response}";
                }

                return response;
            }

            // Check for greetings
            if (lowerInput.Contains("hello") || lowerInput.Contains("hi"))
            {
                string userName = _memoryManager.Recall("UserName");
                return string.IsNullOrEmpty(userName) ? "Hello! How can I help you today?" : $"Hello {userName}! How can I help you today?";
            }

            // Check for help
            if (lowerInput.Contains("help"))
            {
                return "I can help you with: passwords, phishing, scams, privacy, malware, and 2FA. Just ask about any of these topics!";
            }

            // Default response for unknown inputs
            return "I'm not sure I understand. Can you try rephrasing? You can ask me about passwords, phishing, scams, privacy, malware, or 2FA.";
        }

        private string GetKeywordFromInput(string input)
        {
            string[] keywords = { "password", "phishing", "scam", "privacy", "malware", "2fa" };
            foreach (var keyword in keywords)
            {
                if (input.Contains(keyword))
                    return keyword;
            }
            return "";
        }

        public string GetLastTopic()
        {
            return _lastTopic;
        }
    }
}